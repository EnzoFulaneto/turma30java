package com.OdA.ObjAprendizagem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObjAprendizagemApplicationTests {

	@Test
	void contextLoads() {
	}

}
