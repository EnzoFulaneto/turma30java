package com.OdA.ObjAprendizagem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObjAprendizagemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObjAprendizagemApplication.class, args);
	}

}
